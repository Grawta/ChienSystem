package ChienSystem;

public class Model {

}
