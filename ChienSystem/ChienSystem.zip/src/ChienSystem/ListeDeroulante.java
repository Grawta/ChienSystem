//package ChienSystem;
//
//import java.io.FileReader;
//
//public class ListeDeroulante {
//	public static  void init(String nomFichier, ImagePanelA image){
//		String [] tabConv = LectureBufferFichier.lectureFichier(nomFichier);
//		int j =0;
//		while (tabConv[j] !=null){
//			System.out.println(j);
//			System.out.println(tabConv[j]);
//			j++;
//		}
//		int i = 0;
//		image.setListeDeroul("test2");
////		while (tabConv[i] !=null){
////			image.setListeDeroul(tabConv[i]);
////			i++;
////		}
//		
//	}
//
//}
